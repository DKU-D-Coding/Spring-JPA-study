package DKU.Baemin;

import DKU.Baemin.discount.DiscountPolicy;
import DKU.Baemin.discount.FixDiscountPolicy;
import DKU.Baemin.discount.RateDiscountPolicy;
import DKU.Baemin.member.MemberService;
import DKU.Baemin.member.MemberServiceImpl;
import DKU.Baemin.member.MemoryMemberRepository;
import DKU.Baemin.order.OrderService;
import DKU.Baemin.order.OrderServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    //Bean 어노테이션을 통해 스프링 컨테이너에 등록
    public MemberService memberService(){
        return new MemberServiceImpl(memberRepository());
    }

    @Bean
    public static MemoryMemberRepository memberRepository() {
        return new MemoryMemberRepository();
    }

    @Bean
    public OrderService orderService(){
        return new OrderServiceImpl(new MemoryMemberRepository(), discountPolicy());
    }

    @Bean
    public DiscountPolicy discountPolicy(){
        return new RateDiscountPolicy();
    }

}
