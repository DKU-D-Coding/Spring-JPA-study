package DKU.Baemin.member;

public enum Grade{
    BASIC,
    VIP,

}
