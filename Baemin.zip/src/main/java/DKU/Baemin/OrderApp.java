package DKU.Baemin;

import DKU.Baemin.member.Grade;
import DKU.Baemin.member.Member;
import DKU.Baemin.member.MemberService;
import DKU.Baemin.member.MemberServiceImpl;
import DKU.Baemin.order.Order;
import DKU.Baemin.order.OrderService;
import DKU.Baemin.order.OrderServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class OrderApp {
    public static void main(String[] args) {
//        AppConfig appConfig = new AppConfig();
//        MemberService memberService = appConfig.memberService();
//        OrderService orderService = appConfig.orderService();

        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
        MemberService memberService = applicationContext.getBean("memberService",MemberService.class);
        OrderService orderService = applicationContext.getBean("orderService",OrderService.class);


        Long memberId = 1L;
        Member member = new Member(memberId, "kim", Grade.VIP);
        memberService.join(member);


        Order order = orderService.createOrder(memberId,"itemA",9000);
        System.out.println(order);
        System.out.println(order.calculatePrice());
    }
}
