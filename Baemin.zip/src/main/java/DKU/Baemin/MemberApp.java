package DKU.Baemin;

import DKU.Baemin.member.Grade;
import DKU.Baemin.member.Member;
import DKU.Baemin.member.MemberService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MemberApp {
    public static void main(String[] args) {
//        AppConfig appConfig = new AppConfig();
//        MemberService memberService = appConfig.memberService();
//        Memberservice memberService = new MemberServiceImpl();
//        이렇게 쓰는 대신 appconfig에서 생성함으로써 단일책임원칙

        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
        MemberService memberService = applicationContext.getBean("memberService", MemberService.class);

        Member member = new Member(1L,"kim", Grade.VIP);
        memberService.join(member);

        Member findMember = memberService.findMember(1L);
        if(member==findMember){
            System.out.println("success");
        }

    }
}
